<?php
const DOMAINV2B = "speed4g.xyz";
const KEYWORD = ""; //viết thường
const TOKEN = "wMmQ1Jt8KvkMeLgGMCIH2MyvFuWIF9MsZ5Pr9dvLtNmP9kFp6z";
const SIGNATIRE = "88d88057afcd1a0e3ed76d760f0587ebdceacd534ca1894b32efb0fbc969e4aa";
const PHONE = "0333725953";
const WEBHOOK = "https://speed4g.xyz/api/v1/guest/payment/notify/MomoSv3/2YofxjQ0";