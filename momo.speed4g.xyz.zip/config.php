<?php
const DOMAINV2B = "speed4g.xyz";
const KEYWORD = "speed"; //viết thường
const TOKEN = "p2HlNKfkFX3hFV7g1o7Pe3nHFujXPtVOEfiNdO7k2CuR9yeMvf";
const SIGNATIRE = "1672f51ab46ae3d7f4348c41878e2d306e26c61345ed2ba843af7155c7dd3b17";
const PHONE = "0368030503";
const WEBHOOK = "https://speed4g.xyz/api/v1/guest/payment/notify/MomoSv3/ZTPjeOMW";