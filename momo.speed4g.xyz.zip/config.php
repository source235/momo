<?php
const DOMAINV2B = "speed4g.xyz";
const KEYWORD = "speed"; //viết thường
const TOKEN = "4wg3v2rcSVcIALqRrK9JxYtXqY17b4TsgLsKFwZLvvsBIfqP7H";
const SIGNATIRE = "62bedb086a43c878b1e07f91b82804b5ed75600e0778f40b5d75aa19bfaaf89d";
const PHONE = "0333725953";
const WEBHOOK = "https://speed4g.xyz/api/v1/guest/payment/notify/MomoSv3/ZTPjeOMW";