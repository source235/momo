<?php
const DOMAINV2B = "speed4g.xyz";
const KEYWORD = "speed"; //viết thường
const TOKEN = "qr7eyP9eeIY3jU5Y7xCoUWpcKVnLHHys4s5Tfh6RdXrwHCYv2v";
const SIGNATIRE = "62f29163917ec6f6f6404e8971dbcb4731464bee8e5a1050eb702cdcb065ed74";
const PHONE = "0333725953";
const WEBHOOK = "https://speed4g.xyz/api/v1/guest/payment/notify/MomoSv3/2YofxjQ0";