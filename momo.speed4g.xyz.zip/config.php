<?php
const DOMAINV2B = "speed4g.xyz";
const KEYWORD = "speed"; //viết thường
const TOKEN = "yCZRNXA5CIroMmVpuVpTrfr44SXacdULNIzUHICjlACGBVw7k8";
const SIGNATIRE = "4972fb74e1a30643616883a07b1db5bbdca1dbaff1b1eea205423a433e5eb307";
const PHONE = "0333725953";
const WEBHOOK = "https://speed4g.xyz/api/v1/guest/payment/notify/MomoSv3/ZTPjeOMW";