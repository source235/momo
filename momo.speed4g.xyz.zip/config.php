<?php
const DOMAINV2B = "speed4g.xyz";
const KEYWORD = "speed"; //viết thường
const TOKEN = "skDwgkMkgpkrI99421tnIWKCNIgBDZXkNVVI5W1AJii5VORzep";
const SIGNATIRE = "f162f6ea244c24f113a1d399fbf082ffa8d1a4f4cd84f0d220624a515d07ee8b";
const PHONE = "0333725953";
const WEBHOOK = "https://speed4g.xyz/api/v1/guest/payment/notify/MomoSv3/VgZPIjit";