<?php
const DOMAINV2B = "speed4g.net";
const KEYWORD = "speed"; //viết thường
const TOKEN = "hey0koGkiAadxTmM34zTZOFQtMpBOUArnKJoLzkDmjOUQqctEX";
const SIGNATIRE = "ae2f14c132ca4aa9071d8e9aca2770cf1dff3b29855cedc25e44700aafd32323";
const PHONE = "0368030503";
const WEBHOOK = "https://speed4g.net/api/v1/guest/payment/notify/MomoSv3/pIRzMn8e";