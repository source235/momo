<?php
const DOMAINV2B = "speed4g.xyz";
const KEYWORD = ""; //viết thường
const TOKEN = "F1mN3SbJNbhstB0s4S06UO4jMctnC8Ro4oGlxjmN9BNV6hzSib";
const SIGNATIRE = "220128aebad43af648b39d25220432c6953c9c6ac6787d964c827a387d64fd53";
const PHONE = "0333725953";
const WEBHOOK = "https://speed4g.xyz/api/v1/guest/payment/notify/MomoSv3/mCxHWyVC";